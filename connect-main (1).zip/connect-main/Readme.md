# Features

Link: https://linkedin-clone-a077e.web.app

1. Authentication
2. Start a Post
3. Update a Post
4. Delete a Post
5. Add Connections
6. Like and Comment on a Post
7. Update Profile
8. See Other Profiles
9. Add a Profile Picture
10. Add Post Images
11. Search For Other Users

If you want to learn how to build this, follow my tutorial here:

Linkedin Clone - React and Firebase Full Tutorial.

Check the playlist for the videos: https://lnkd.in/d6JvCm-t